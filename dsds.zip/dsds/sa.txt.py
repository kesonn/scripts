from pytesser import image_to_string

from PIL import Image

image = Image.open('verify.html.png')

vcode = image_to_string(image)

print(vcode)